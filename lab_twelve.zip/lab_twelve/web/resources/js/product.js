$(document).ready(function () {
 /*   $('#assign_sample').on('change', function () {
        var parts = $('#assign_sample').val().split("-");
        var data = {sample: parts[0], request: parts[1]};

        $.ajax("/match_sample_to_request"
            , {
                "type": "POST",
                "data": data,
            }).done(function (data) {
                window.location = "/dashboard";
            }
        ).fail(function () {
        });
    });

    $('#edit_sample').on('click', function () {
        $("#divInfo").load("/resources/js/info.txt");
    });

    $("#contactInfo").click(function (event) {

        $.getJSON('/resources/js/contact.json', function (jd) {
            $('#details').html('<p> Member1: ' + jd.member1.name + ' (' + jd.member1.email + ') ' + '</p>');
        });

    });*/
});